<?php
use xmpush\Builder;
use xmpush\Sender;
use xmpush\Constants;
use xmpush\Stats;
use xmpush\TargetedMessage;
include_once(dirname(__FILE__).'/autoload.php');

$secret = 'rypZH3SPOuWbIMTYc6oC5XEU2gJiYtmGFS+3XXKA6V0=';
$package = 'com.xiaomi.mipushdemo';

Constants::setPackage($package);
Constants::setSecret($secret);

$aliasList = array('alias1', 'alias2');
$title = '你好';
$desc = '这是一条mipush推送消息';
$payload = '{"test":1,"ok":"It\'s a string"}';

$sender = new Sender();

$message = new Builder();
$message->title($title);
$message->description($desc);
$message->passThrough(0);
$message->payload($payload);
$message->extra(Builder::notifyForeground, 1);
$message->notifyId(2);
$message->build();
$targetMessage = new TargetedMessage();
$targetMessage->setTarget('alias1', TargetedMessage::TARGET_TYPE_ALIAS);
$targetMessage->setMessage($message);

$message2 = new Builder();
$message2->title($title);
$message2->description($desc);
$message2->passThrough(0);
$message2->payload($payload);
$message2->extra(Builder::notifyEffect, 1);
$message2->extra(Builder::notifyForeground, 1);
$message2->notifyId(0);
$message2->build();
$targetMessage2 = new TargetedMessage();
$targetMessage2->setTarget('alias2', TargetedMessage::TARGET_TYPE_ALIAS);
$targetMessage2->setMessage($message2);

$targetMessageList = array($targetMessage, $targetMessage2);
//print_r($sender->multiSend($targetMessageList,TargetedMessage::TARGET_TYPE_ALIAS)->getRaw());

print_r($sender->sendToAliases($message,$aliasList)->getRaw());
//$stats = new Stats();
//$startDate = '20140301';
//$endDate = '20140312';
//print_r($stats->getStats($startDate,$endDate)->getStats());

?>
