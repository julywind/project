<?php
/**
 * 错误码定义.
 * @author wangkuiwei
 * @name ErrorCode
 * @desc 错误码
 *
 */
namespace xmpush;

class ErrorCode {
	const Success = 0;
}

?>
