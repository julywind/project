<?php
/**
 * 获取发送的消息统计数据.
 * @author wangkuiwei
 * @name Stats
 * @desc 获取发送的消息统计数据。
 *
 */
namespace xmpush;

class Stats {
	private $appSecret;
	private $package;	//android用
	private $bundle;	//ios用
	
	public function __construct(){
		$this->appSecret = Constants::$secret;
		$this->package = Constants::$packageName;
		$this->bundle = Constants::$bundle_id;
	}
	
	public function getStats($startDate,$endDate,$type='android',$retries=1){
		if($type == 'ios'){
			$fields = array(
					'start_date' => $startDate,
					'end_date' => $endDate,
					'restricted_package_name' => $this->bundle
			);
		}else{
			$fields = array(
					'start_date' => $startDate,
					'end_date' => $endDate,
					'restricted_package_name' => $this->package
			);
		}
		$url = Constants::$domain.Constants::stats_url;
		$result = $this->getResult($url, $fields, $retries);
		return $result;
	}
	
	//发送请求，获取result，带重试
	private function getResult($url,$fields,$retries,$timeout=3){
	    $result = new Result($this->getReq($url, $fields),true);
	    if($result->getErrorCode() == ErrorCode::Success){
	        return $result;
	    }
	    //重试
	    for($i=0;$i<$retries;$i++){
	        $result = new Result($this->getReq($url, $fields),true);
	        if($result->getErrorCode() == ErrorCode::Success){
	            break;
	        }
	    }
	    return $result;
	}
	
	//get方式发送请求
	private function getReq($url,$fields,$timeout=3){
	    $headers = array('Authorization: key=' . $this->appSecret, 'Content-Type: application/x-www-form-urlencoded');
	    // Open connection
	    $ch = curl_init();
	
	    curl_setopt($ch, CURLOPT_URL, $url.'?'.http_build_query($fields));
	    curl_setopt($ch, CURLOPT_POST, false);
	    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
	    curl_setopt ( $ch, CURLOPT_CONNECTTIMEOUT, $timeout );
	    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	
	    // Execute post
	    $result = curl_exec($ch);
	
	    // Close connection
	    curl_close($ch);
	    return $result;
	}
}

?>
