<?php
/**
 * 常量定义.
 * @author wangkuiwei
 * @name Constants
 * @desc 常量定义
 *
 */
namespace xmpush;

class Constants {
	public static $domain = 'https://api.xmpush.xiaomi.com';
	public static $comma = ',';
	public static $packageName = '';
	public static $bundle_id = '';
	public static $secret = '';
	
	const reg_url = '/v2/message/regid';
	const alias_url = '/v2/message/alias';
	const topic_url = '/v2/message/topic';
	const multi_messages_regids_url = '/v2/multi_messages/regids';
	const multi_messages_aliases_url = '/v2/multi_messages/aliases';
	const stats_url = '/v1/stats/message/counters';
	
	public static function setPackage($package){
		self::$packageName = $package;
	}
	
	public static function setSecret($secret){
		self::$secret = $secret;
	}

	public static function setBundleId($bundleId){
		self::$bundle_id = $bundleId;
	}
	
	public static function useOfficial(){
		self::$domain = 'https://api.xmpush.xiaomi.com';
	}
	
	public static function useSandbox(){
		self::$domain = 'https://sandbox.xmpush.xiaomi.com';
	}
}

?>
