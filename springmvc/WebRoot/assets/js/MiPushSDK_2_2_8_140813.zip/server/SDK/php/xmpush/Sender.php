<?php
/**
 * MiPush消息发送类.
 * @author wangkuiwei
 * @name Sender
 * @desc MiPush消息发送
 *
 */
namespace xmpush;

class Sender {
	private $appSecret;
	
	public function __construct(){
		$this->appSecret = Constants::$secret;
	}
	
	//指定regId单发消息
	public function send(Message $message,$regId,$retries=1){
		$fields = $message->getFields();
		$fields['registration_id'] = $regId;
		$url = Constants::$domain.Constants::reg_url;
		return $this->postResult($url, $fields,$retries);
	}
	
	//指定regId列表群发
	public function sendToIds(Message $message,$regIds,$retries=1){
		$fields = $message->getFields();
		$jointRegIds = '';
		foreach($regIdList as $regId){
			if(isset($regId)){
				$jointRegIds .= $regId.Constants::$comma;
			}
		}
		$fields['registration_id'] = $jointRegIds;
		$url = Constants::$domain.Constants::reg_url;
		return $this->postResult($url, $fields,$retries);
	}
	
	//多条发送
	public function multiSend($targetMessages,$type,$retries=1){
		if($type == TargetedMessage::TARGET_TYPE_ALIAS){
			$url = Constants::$domain.Constants::multi_messages_aliases_url;
		}else{
			$url = Constants::$domain.Constants::multi_messages_regids_url;
		}
		$data = array();
		foreach($targetMessages as $targetMsg){
			array_push($data,$targetMsg->getFields());
		}
		$fields = array('messages' => json_encode($data));
		return $this->postResult($url, $fields,$retries);
	}
	
	//指定别名单发
	public function sendToAlias(Message $message,$alias,$retries=1){
		$fields = $message->getFields();
		$fields['alias'] = $alias;
		$url = Constants::$domain.Constants::alias_url;
		return $this->postResult($url, $fields, $retries);
	}
	
	//指定别名列表群发
	public function sendToAliases(Message $message,$aliasList,$retries=1){
		$fields = $message->getFields();
		$jointAliases = '';
		foreach($aliasList as $alias){
			if(isset($alias)){
				$jointAliases = $jointAliases.$alias.Constants::$comma;
			}
		}
		$fields['alias'] = $jointAliases;
		$url = Constants::$domain.Constants::alias_url;
		return $this->postResult($url, $fields, $retries);
	}
	
	//指定topic群发
	public function broadcast(Message $message,$topic,$retries=1){
		$fields = $message->getFields();
		$fields['topic'] = $topic;
		$url = Constants::$domain.Constants::topic_url;
		return $this->postResult($url, $fields, $retries);
	}
	
	//发送请求，获取result，带重试
	private function postResult($url,$fields,$retries){
		$result = new Result($this->postReq($url, $fields));
		if($result->getErrorCode() == ErrorCode::Success){
		    return $result;
		}
		//重试
		for($i=0;$i<$retries;$i++){
		    $result = new Result($this->postReq($url, $fields));
		    if($result->getErrorCode() == ErrorCode::Success){
		        break;
		    }
		}
		return $result;
	}
	
	//post方式发送请求
	private function postReq($url,$fields,$timeout=10){
	    $headers = array('Authorization: key=' . $this->appSecret, 'Content-Type: application/x-www-form-urlencoded');
	    // Open connection
	    $ch = curl_init();
	
	    // Set the url, number of POST vars, POST data
	    curl_setopt($ch, CURLOPT_URL, $url);
	    curl_setopt($ch, CURLOPT_POST, false);
	    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
	    curl_setopt ( $ch, CURLOPT_CONNECTTIMEOUT, $timeout );
	    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($fields));
	    print_r('HTTP Params <br> '.urldecode(http_build_query($fields)));
	    echo'<br>';
	    // Execute post
	    $result = curl_exec($ch);
	    	
	    // Close connection
	    curl_close($ch);
	    return $result;
	}
	
}

?>
