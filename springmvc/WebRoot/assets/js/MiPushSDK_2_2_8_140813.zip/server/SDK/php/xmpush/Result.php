<?php
/**
 * 服务器返回的结果.
 * @author wangkuiwei
 * @name Result
 * @desc Sender发送消息后，服务器返回的结果。
 *
 */
namespace xmpush;

class Result {
	private $messageId;
	private $errorCode;
	private $reason;
	private $raw;
	
	public function __construct($jsonStr,$statsResult=false){
		$data = json_decode($jsonStr,true);
		if($statsResult && isset($data['data']['data'])){
			$data['data']['data'] = json_decode($data['data']['data'],true);
		}
		$this->raw = $data;
		
		//返回结果不为json，默认为超时
		if(json_last_error() != JSON_ERROR_NONE){
			$this->messageId = '';
			$this->reason = 'request time out';
			$this->errorCode = -1;
		}else{
			$this->errorCode = $data->code;
			if($data->code == ErrorCode::Success){
				$this->messageId = $data->data->id;
				$this->reason = null;
			}else{
				$this->messageId = '';
				$this->reason = $data->description;
			}
			
		}
	}
	
	public function getMessageId(){
		return $this->messageId;
	}
	
	public function getErrorCode(){
		return $this->errorCode;
	}
	
	public function getReason(){
		return $this->reason;
	}
	
	public function getRaw(){
		return $this->raw;
	}
	
	public function getStats(){
		return isset($this->raw['data']['data']) ? $this->raw['data']['data'] : array();
	}
}

?>
